README - Darood Sharif Animation Setup

1. Upload both files (index.html and your darood.mp3) to your GitHub repository.
2. Go to Settings → Pages → choose "Deploy from a branch", branch: main, folder: / (root).
3. Save and wait for the site to deploy.
4. Visit https://your-username.github.io/your-repo-name/
5. If sound doesn’t start automatically, tap once on the page.

Enjoy your animated Darood Sharif page with looping audio.
